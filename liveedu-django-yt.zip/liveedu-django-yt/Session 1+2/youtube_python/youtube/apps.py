from django.apps import AppConfig


class YoutubeConfig(AppConfig):
    name = 'youtube'
